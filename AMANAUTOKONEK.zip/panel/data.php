<?php 
$nik = "WEB || AKBARZ NS";
$sender = "admin@Akbarz.co.id";
?>